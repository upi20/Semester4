/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iseplutpinur;

/**
 * Nama: Isep Lutpi Nur
 * NPM : 2113191079
 * Kelas : A2
 */
public class Helloworld {
    public static void main(String[] args) {
        // TODO code application logic here
        char kar; // deklarasi / pendefinisian variable
        kar = 'A';
        System.out.print("Karakter adalah= ");
        System.out.print(kar);
        
        kar = 75; // Memberikan nilai ascii ke variable
        System.out.print("\nkarakter adalah = ");
        System.out.print(kar);
        
    }
}
